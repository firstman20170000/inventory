-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: w3_thepanelizer
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `job_status`
--

DROP TABLE IF EXISTS `job_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `job_status` (
  `status_id` int(255) NOT NULL AUTO_INCREMENT,
  `string_status` varchar(255) DEFAULT NULL,
  `int_status` int(255) DEFAULT NULL,
  `str_ne_status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_status`
--

LOCK TABLES `job_status` WRITE;
/*!40000 ALTER TABLE `job_status` DISABLE KEYS */;
INSERT INTO `job_status` VALUES (1,'Job Not Defined',0,'Create Job','2019-04-10 02:12:02',NULL,NULL),(2,'Job Information Updated',20,'Gerber files need to be uploaded to the server','2019-04-10 02:12:02',NULL,NULL),(3,'Gerbers have been uploaded successfully',40,'Design will have space allocated on the next panel','2019-04-10 02:12:02',NULL,NULL),(4,'Design files have been downloaded',45,'Design will be DRCd','2019-04-10 02:12:02',NULL,NULL),(5,'Design has been allocated space on a panel',60,'Design is on the panel that will soon be fabricate...','2019-04-10 02:12:02',NULL,NULL),(6,'Design is being fabricated',80,'Design will arrive shortly','2019-04-10 02:12:02',NULL,NULL),(7,'Boards have been sent to The Panelizer users ',100,'Done','2019-04-10 02:12:02',NULL,NULL),(8,'Boards have been delivered to The Panelizer Hive',95,'Full shipment soon','2019-04-10 02:12:02',NULL,NULL),(9,'Gerbers have been rejected for DRC violations.',30,'Upload new gerbers. Board will not be run without..','2019-04-10 02:12:02',NULL,NULL),(10,'Design files have passed DRC checks',50,'Design is ready for panelization','2019-04-10 02:12:02',NULL,NULL);
/*!40000 ALTER TABLE `job_status` ENABLE KEYS */;
UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-19 11:13:33
