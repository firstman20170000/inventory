-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: w3_thepanelizer
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_group` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_street` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address_city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_state_province` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address_zip_postal` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','status@thepanelizer.com',NULL,'$2y$10$HwGEKjNP8z2542lOtCgzVutHlTyqh0A.ajpFsztgfIvLa0/krOMiy','','','','MJAmbP3vHjivEKOc2T44Qe9YX0kbVuMzm0vzwOogyRmEbCo3DKRRdY8RIHVJ','2019-04-03 23:31:31','2019-04-03 23:31:31','','',''),(5,'NVergunst','Nick.Vergunst@gmail.com',NULL,'$2y$10$qfckdkPsnHkyySl8iY9tCew/hmnrxobODtPiZe7HOH3GvHUz0pN9C','Myself','Myself','1915 Hunters Point Lane',NULL,'2019-04-10 09:04:29','2019-04-10 09:04:29','Colorado Springs','CO','80919'),(7,'mpeters76','michael.peters@analog.com',NULL,'$2y$10$6g/M59jb6mc2isPnb9wPpO3XlYdSooXDs5uz.Aplqv8LYh0gOeKm6','Analog Devices Inc','PSM','950 Chapel Hills Dr',NULL,'2019-04-11 18:33:19','2019-04-11 18:33:19','Colorado Springs','Colorado','80920'),(9,'blackcat','blackcat20180000@gmail.com',NULL,'$2y$10$pBpou7qkP2CqCXX7mcUe7eKleUm0X8fCog56/LkJgjeRKEonheoGu','aa','aa','aa','GSV2cw8eQqHG4qnAt1eX99viaLAFqxHfiGEAzsy9kzc6Y4dfqEqwWZ5Ymztv','2019-04-11 21:46:46','2019-04-11 21:46:46','aa','aa','aa'),(10,'cat','cat201800@gmail.com',NULL,'$2y$10$lMOhAN9Pay5ujHp4UhOhF.3CwCMQSjW8hfLu2esQXpRc6Y0rmyvMS','aa','aa','aa',NULL,'2019-04-11 21:48:11','2019-04-11 21:48:11','aa','aa','aa'),(11,'FakeUser@gmail.com','FakeUser@gmail.com',NULL,'$2y$10$1m1pxHdKG.fobG.OklnKQu1GuzrTM0IyFuVf.fWeAVVEWO031S8Sq','AAA','AAA','AAA',NULL,'2019-04-13 04:05:22','2019-04-13 04:05:22','AAA','AAA','11111'),(12,'AnotherFake@fake.com','AnotherFake@fake.com',NULL,'$2y$10$dJWU54rOADiX3fxKfPP4RetNiJDc9WpPczNyJgy5ZLnzhbpZ/YjMe','Fake','fake','fake',NULL,'2019-04-13 04:08:53','2019-04-13 04:08:53','fake','fa','11111'),(13,'aaa','aaa@admin.com',NULL,'$2y$10$q9UDuaQS1S9riEE3IvEOSeDwBAJ0kxauot9sObMHjhcOTR2JAPMi2','aaa','aaa','sss',NULL,'2019-04-14 19:09:43','2019-04-14 19:09:43','vladivostok','moscow','12'),(14,'Newone','themostfriend@gmail.com',NULL,'$2y$10$lOkByN6IuWXVUPYAr7h2wuAe6iSp7tjdJb5iEW/UMVKLSkDG4Qb7u','11','11','11',NULL,'2019-04-16 01:50:44','2019-04-16 01:50:44','11','11','111111'),(15,'111','111@gmail.com',NULL,'$2y$10$hYCxl8sICLfTbuI6KPTKfedu7n9ZfUJChUINLYrDggAe.j.CHO9Cm','11','11','11',NULL,'2019-04-16 07:54:24','2019-04-16 07:54:24','11','11','111111'),(16,'Tom Westenburg','Thomas.Westenburg@Analog.com',NULL,'$2y$10$UTuzOrxwU2A/o4yDd1blm.FTMiRjciEOFo4nnRVGDy99Yrt/MMeDy','Analog Devices Inc.','BMS','950 Chapel Hills Drive','jlpRpLVFehri927sagP8alfGXdRwVcbSxuxIFV36qtUSZtyPYzuON4nMYgwe','2019-06-03 20:39:07','2019-06-03 20:39:07','Colorado Springs','CO','80920');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-19 11:13:34
